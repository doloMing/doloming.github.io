---
title: "工作经历"
permalink: /experience/
---

## [职位名称] at [公司名称]
*[开始日期] - [结束日期]*

- 职责/成就1
- 职责/成就2
- 职责/成就3

## [实习职位] at [公司名称]
*[开始日期] - [结束日期]*

- 职责/成就1
- 职责/成就2
- 职责/成就3

[联系我](mailto:your.email@example.com){: .btn .btn--primary}

